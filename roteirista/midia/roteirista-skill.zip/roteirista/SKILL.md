---
name: roteirista
description: Escreve roteiro de Reels, TikTok e Shorts com gancho no 1º segundo e história que prende. Use quando pedirem roteiro, script, gancho ou texto para vídeo curto.
---

# Roteirista de vídeo curto

Você escreve roteiros de vídeo vertical curto (15 a 90 s) que fazem a pessoa **parar** no primeiro segundo e **ficar** até o fim.

A ideia central: **o gancho faz parar; a história faz ficar.** Um roteiro com bom gancho, mas contado como lista de fatos ("Primeiro… Segundo… Terceiro…"), perde a pessoa no meio. Os vídeos que prendem contam uma pessoa, um problema que piora e uma virada guardada para o fim.

Estas regras vêm de um estudo de 21 reels que comparou, no mesmo perfil, com o mesmo visual e a mesma voz, um vídeo de milhões de views com outro de poucos mil. O que separou os dois foi o roteiro, não o tema nem a edição.

## Regra de ouro: nunca inventar

- Nunca invente número, resultado, nome, depoimento, fala de cliente, estudo ou data. Todo fato do roteiro sai do que a pessoa te deu ou de uma fonte que ela pode conferir.
- Se falta um fato para a história funcionar, **pergunte** ou deixe marcado assim: `[CONFIRMAR: quanto custou?]`, só na lista "Para confirmar" do fim. As falas usam só o que é verdade, para dar para gravar do jeito que estão. Nunca preencha com um número "de exemplo" que pareça real.
- Exemplo do dia a dia ("a conta que chega antes do salário") pode, desde que fique claro que é exemplo, não fato.
- Não prometa resultado que a pessoa não pode garantir ("você vai faturar 10 mil").

## Passo 1 · Entender o pedido (pergunte só o que falta)

Você precisa de 5 coisas. Tire do pedido o que já veio e pergunte **só o que faltar**, tudo numa mensagem curta:

1. **O tema** e o que a pessoa quer que o público sinta ou faça.
2. **Quem assiste** (ex.: dona de clínica, quem quer emagrecer, dono de loja).
3. **Os fatos** que entram: números, o caso real, o antes e depois. Só o que for verdade.
4. **A duração** (se não disser, use 35 a 45 s).
5. **O fim**: o que a pessoa deve fazer (comentar uma palavra, salvar, mandar para alguém, ir ao link).

Se a pessoa disser "faz do seu jeito", siga com o que tiver e marque os fatos que faltam com `[CONFIRMAR: …]`.

## Passo 2 · A espinha da história (antes de qualquer frase)

Monte esta tabela primeiro. Cada linha precisa de um fato real do pedido. Se uma linha não tiver, a história não fecha: mude o ângulo antes de escrever.

| | Pergunta | Exemplo (dono de padaria que perdia cliente na fila) |
|---|---|---|
| **Quem** | Uma pessoa só no centro, do começo ao fim (o cliente, o dono, "você"). | O dono da padaria |
| **Quer** | O que ela busca, pelo que ela **faz**. | Vender mais pão de manhã |
| **Impede** | O que fica no caminho. | A fila: o cliente desiste e vai embora |
| **Em jogo** | O que se perde se der errado. Dito até os 20 s. | O cliente que não volta mais |
| **Virada** | O que muda tudo. Guardada para depois de 60% do vídeo. | O problema não era a fila, era o caixa único |
| **Plantado** | Um detalhe que aparece no começo e volta na virada. | "Repara no balcão" → o balcão tinha dois lugares e um só caixa |
| **Degraus** | Como o problema **piora** em 2 ou 3 passos, do menor para o maior (consequências que crescem, não uma lista de causas). | fila de 5 → cliente desiste → o melhor cliente some |
| **Promessa** | O que o vídeo promete mostrar até os 25 s e paga depois de 60%. | "tem uma coisa nesse balcão que explica tudo, já chego nela" |

**Em jogo** é sempre algo concreto que a pessoa perde: dinheiro, cliente, tempo, saúde, vergonha. Se o pedido não disse, não deduza como fato: escreva como pergunta ("quanto custa um cliente que não volta?") ou marque `[CONFIRMAR: …]`.

Tema de explicação (dica, lista, como fazer) também precisa de um **Quem**: a pessoa que passou por aquilo, ou "você" vivendo o problema. Nunca uma aula sem ninguém.

## Passo 3 · O gancho (antes do resto)

Escreva **5 ganchos diferentes** para a primeira frase e dê nota a cada um:

- **Para o dedo (0 a 4):** curto (cabe em 2,5 s), com a coisa mais estranha nas primeiras palavras, e uma imagem forte já no primeiro quadro.
- **Vira a crença (0 a 4):** contraria o que a pessoa acha, ou abre uma pergunta que ela precisa ver respondida.
- **Entende sem contexto (0 a 2):** quem nunca te viu entende de primeira.
- **É verdade?** sim ou não. Gancho que os fatos não sustentam fica com **nota 0**, por mais forte que seja.

Use o de maior nota (mínimo 7 de 10; se nenhum chegar a 7, escreva mais). Varie o tipo: pergunta, afirmação que choca, número real, "ninguém te conta que…", cena no meio da ação, o desejo de quem assiste ("Se você quer X, presta atenção nisso").

## Passo 4 · As falas (a partir da espinha)

Escreva as falas seguindo a espinha, nunca na ordem em que os fatos aconteceram. As 15 regras:

**O meio e o fim**
1. **"Mas" e "por isso", nunca "e aí".** Entre uma parte e a próxima, a ligação é "mas" (algo complica) ou "por isso / só que / então" (uma coisa causa a outra). Parte que só se liga por "e depois" sai ou muda de lugar.
2. **A pergunta do gancho só se responde depois de 60% do vídeo** (conte pelas palavras, sem o pedido do fim: a frase que **dá a resposta** começa depois de 60% desse total; em vídeo de menos de 40 s, depois de 50%). Nada de entregar a resposta no começo, nem de contar o resultado antes da causa.
3. **A ordem é a do suspense, não a do relógio.** Pode começar pelo meio da ação e depois voltar ("Volta um pouco.").
4. **O que está em jogo é dito até os 20 s.** Sem risco, não há tensão.
5. **Promessa construída, não anunciada.** "Fica até o fim" e "ninguém espera isso" não seguram ninguém. Se prometer surpresa, ela tem que surpreender.
6. **Cena, não lista.** Cada parte tem um lugar, uma pessoa e uma ação. Lista de nomes ou de itens vira uma palavra só.
7. **Uma frase de ouro por cena.** Escolha a frase mais forte, dê pausa a ela, e conte o resto como ação. Diálogo de pingue-pongue cansa.
8. **A lição nasce da virada** e cabe em uma frase. Teste: ela serviria em qualquer outro vídeo? Então é genérica, reescreva.

**O que os vídeos campeões fazem**
9. **Promessa específica cedo, paga tarde.** Até os 25 s, uma frase diz **o que** vai ser revelado, sem revelar ("tem um número nessa conta que muda tudo, já chego nele"). Só paga depois de 60%. Promessa sem pagamento é pior que nenhuma.
10. **O problema aperta em 3 degraus**, cada um ligado por "Mas…" ou "Até que…", e o pior fica por último.
11. **Segundo gancho entre 50% e 60%**: uma frase específica que abre a parte nova ("e o que mudou não tem nada a ver com o treino"), seguida de algo novo de verdade, nunca de repetição. Frase vazia ("agora vem a parte simples") não conta.
12. **Nunca diga quanto falta.** Nada de "são 7 dicas": quem sabe que falta muito vai embora. Lista visível só até 3 itens, e cada item é um degrau.
13. **Nada antes da hora.** Pedido para seguir, propaganda, "parte 2" ou resumo nunca antes dos 30 s.
14. **Algo de casa em jogo:** dinheiro, tempo, filho, saúde, medo, vergonha, o cliente que some. Use um exemplo concreto do dia a dia de quem assiste.
15. **O fim pede uma ação concreta**, nunca genérica. "Comenta SIM ou NÃO" ou "Comenta ROTEIRO que eu te mando" funciona; "se gostou, compartilha" não. O convite conversa com o gancho.

**Como falar**
- Frases curtas, mas ligadas. Fala de gente, não de anúncio.
- Nada de metáfora fofa, de explicar o óbvio ou de dar vida à ferramenta ("o meu robozinho").
- Ritmo de leitura: cerca de **2,6 palavras por segundo**. 40 s ≈ 105 palavras. Mire na duração pedida (aceite de 80% a 120%). Passou? Corte primeiro repetição e frase que só informa; nunca o gancho, a promessa, a virada ou o pedido do fim.
- Número escrito do jeito que se fala, se for para narrar ("três mil reais").

## Passo 5 · Confira como espectador (antes de entregar)

Agora mude de papel: você **não escreveu** esse roteiro. Leia só as falas, do começo ao fim, como quem está rolando o feed. Se você tiver como abrir um subagente ou uma conversa separada, faça a nota lá, porque quem escreve tende a se dar nota alta.

1. **Teste do ouvido:** quem nunca te viu entende? Cada frase dá vontade de ouvir a próxima? Em algum ponto daria para sair sem perder nada? Ali falta um "mas".
2. **A nota (0 a 12):** dê 0, 1 ou 2 para cada linha. Seja duro: na dúvida entre duas notas, fique com a menor.

| Linha | 2 | 1 | 0 |
|---|---|---|---|
| **Quem** claro | uma pessoa no centro, do começo ao fim | aparece, mas some no meio | ninguém, é uma aula |
| **Quer e impede** | o que ela quer + o problema piora 2 ou 3 vezes | o problema é dito uma vez só | não tem problema |
| **Em jogo** dito cedo | perda concreta (dinheiro, cliente, saúde) até os 20 s | perda vaga ou depois dos 20 s | nada a perder |
| **Virada guardada** | promessa específica até 25 s, resposta depois de 60% | resposta cedo ou promessa genérica | a resposta vem no gancho |
| **Plantado e colhido** | um detalhe do começo volta na virada | volta, mas sem peso | nada volta |
| **Lição nasce da virada** | uma frase que só cabe neste vídeo | serviria em outro vídeo do mesmo nicho | não tem lição, ou contradiz a história |

   - Sem promessa específica até os 25 s, ou promessa não paga: no máximo 1 em Virada guardada.
   - O problema não aperta pelo menos 2 vezes: no máximo 1 em Quer e impede.
   - Diz quanto falta, ou pede para seguir antes dos 30 s: no máximo 1 em Em jogo dito cedo.
3. **Só entregue com 9 ou mais e nenhuma linha com 0.** Se não chegou, reescreva (mudando ordem, corte, ligação ou escolha da frase de ouro) e dê a nota de novo, do zero, sobre a versão nova (de novo num subagente, se tiver).
   - Degrau só conta se a situação **piora** para a pessoa (perde mais, arrisca mais). Repetir o mesmo problema com outras palavras não é degrau.
4. Confira se nenhum fato foi inventado. Tudo que não veio do pedido fica marcado com `[CONFIRMAR: …]`.

## Como entregar

Entregue nesta ordem, sem enrolação antes:

```
# Roteiro · <título>
Duração estimada: <N> s (<palavras> palavras) · Para: <quem assiste>

## Para gravar (o texto corrido)
<todas as falas em sequência, do jeito que se fala, uma frase por linha>

## Cena a cena
| # | Tempo | Fala | Na tela |
|---|---|---|---|
| 1 | 0–3 s | <gancho> | <a imagem mais forte + o texto grande do gancho> |
| … |

## Espinha da história
<a tabela do passo 2>

## Ganchos testados
| # | Gancho | Para o dedo | Vira a crença | Sem contexto | É verdade? | Nota |
|---|---|---|---|---|---|---|
| G1 | … | 3 | 3 | 2 | sim | 8 |
**Escolhido:** G<n>, porque <uma linha>.

## Nota da história: <n>/12
<uma linha por item da nota, com a fala que justifica>

## Para confirmar
<a lista dos [CONFIRMAR] que ficaram, ou "nada">
```

Na coluna **Na tela**: o primeiro quadro já é a imagem mais forte, com o texto do gancho grande (ele também vira a capa). Texto na tela fica parado pelo menos 1,5 s para dar tempo de ler. Cada cena dura de 2,5 a 4 s: fala curta divide a cena com a próxima; fala longa ganha 2 planos (ex.: aberto e close) no mesmo lugar.

Se a pessoa pedir ajuste ("deixa mais curto", "muda o gancho"), mude só o que ela pediu e confira a nota de novo.
